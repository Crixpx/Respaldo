ALTER TABLE bans ADD COLUMN ban_hash varchar(255);
